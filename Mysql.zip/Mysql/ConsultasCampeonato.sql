use campeonato;

INSERT INTO Teams (nameTeam, cityOrigin, foundationYear) VALUES
('Equipo A', 'Ciudad A', 1990),
('Equipo B', 'Ciudad B', 1992),
('Equipo C', 'Ciudad C', 1985),
('Equipo D', 'Ciudad D', 2000),
('Equipo E', 'Ciudad E', 2005),
('Equipo F', 'Ciudad F', 2010),
('Equipo G', 'Ciudad G', 2015),
('Equipo H', 'Ciudad H', 2020);

-----------------------------------------------------------
-- Jugadores para el Equipo A
INSERT INTO Players (nameComplete, numberTShirt, position, idTeam) VALUES
('Jugador 1', 1, 'Goalkeeper', 1),
('Jugador 2', 2, 'Defense', 1),
('Jugador 3', 3, 'Midfielder', 1),
('Jugador 4', 4, 'Forward', 1),
('Jugador 5', 5, 'Midfielder', 1);

-- Jugadores para el Equipo B
INSERT INTO Players (nameComplete, numberTShirt, position, idTeam) VALUES
('Jugador 6', 6, 'Goalkeeper', 2),
('Jugador 7', 7, 'Defense', 2),
('Jugador 8', 8, 'Midfielder', 2),
('Jugador 9', 9, 'Forward', 2),
('Jugador 10', 10, 'Midfielder', 2);

-- Jugadores para el Equipo C
INSERT INTO Players (nameComplete, numberTShirt, position, idTeam) VALUES
('Jugador 11', 11, 'Goalkeeper', 3),
('Jugador 12', 12, 'Defense', 3),
('Jugador 13', 13, 'Midfielder', 3),
('Jugador 14', 14, 'Forward', 3),
('Jugador 15', 15, 'Midfielder', 3);

-- Jugadores para el Equipo D
INSERT INTO Players (nameComplete, numberTShirt, position, idTeam) VALUES
('Jugador 16', 16, 'Goalkeeper', 4),
('Jugador 17', 17, 'Defense', 4),
('Jugador 18', 18, 'Midfielder', 4),
('Jugador 19', 19, 'Forward', 4),
('Jugador 20', 20, 'Midfielder', 4);

-- Jugadores para el Equipo E
INSERT INTO Players (nameComplete, numberTShirt, position, idTeam) VALUES
('Jugador 21', 21, 'Goalkeeper', 5),
('Jugador 22', 22, 'Defense', 5),
('Jugador 23', 23, 'Midfielder', 5),
('Jugador 24', 24, 'Forward', 5),
('Jugador 25', 25, 'Midfielder', 5);

-- Jugadores para el Equipo F
INSERT INTO Players (nameComplete, numberTShirt, position, idTeam) VALUES
('Jugador 26', 26, 'Goalkeeper', 6),
('Jugador 27', 27, 'Defense', 6),
('Jugador 28', 28, 'Midfielder', 6),
('Jugador 29', 29, 'Forward', 6),
('Jugador 30', 30, 'Midfielder', 6);

-- Jugadores para el Equipo G
INSERT INTO Players (nameComplete, numberTShirt, position, idTeam) VALUES
('Jugador 31', 31, 'Goalkeeper', 7),
('Jugador 32', 32, 'Defense', 7),
('Jugador 33', 33, 'Midfielder', 7),
('Jugador 34', 34, 'Forward', 7),
('Jugador 35', 35, 'Midfielder', 7);

-- Jugadores para el Equipo H
INSERT INTO Players (nameComplete, numberTShirt, position, idTeam) VALUES
('Jugador 36', 36, 'Goalkeeper', 8),
('Jugador 37', 37, 'Defense', 8),
('Jugador 38', 38, 'Midfielder', 8),
('Jugador 39', 39, 'Forward', 8),
('Jugador 40', 40, 'Midfielder', 8);
------------------------------------------------------------------------------

INSERT INTO Referees (nameComplete, experienceYears, category) VALUES
('Árbitro Principal 1', 10, 'Principal'),
('Árbitro Asistente 1', 5, 'Assistant'),
('Árbitro Asistente 2', 7, 'Assistant');
__________________________________________________________________________________

INSERT INTO Matches (idLocalTeam, idVisitingTeam, matchDay, idPrincipalReferee, localTeamGoals, visitingTeamGoals, phase) VALUES
(1, 2, '2025-03-01', 1, 2, 1, 'Cuartos'),
(3, 4, '2025-03-02', 1, 3, 2, 'Cuartos'),
(5, 6, '2025-03-03', 1, 1, 1, 'Cuartos'),
(7, 8, '2025-03-04', 1, 0, 2, 'Cuartos');
__________________________________________________________________________________

INSERT INTO Match_Referees (idMatch, idReferee, category) VALUES
(1, 1, 'Principal'),
(1, 2, 'Assistant'),
(1, 3, 'Assistant'),
(2, 1, 'Principal'),
(2, 2, 'Assistant'),
(2, 3, 'Assistant'),
(3, 1, 'Principal'),
(3, 2, 'Assistant'),
(3, 3, 'Assistant'),
(4, 1, 'Principal'),
(4, 2, 'Assistant'),
(4, 3, 'Assistant');
---------------------------------------------------------------------------------

-- CONSULTAS

SELECT nameTeam, cityOrigin
FROM Teams
ORDER BY nameTeam ASC;
____________________________

SELECT p.nameComplete, p.numberTShirt, p.position
FROM Players p
JOIN Teams t ON p.idTeam = t.idTeam
WHERE t.nameTeam = 'Equipo A';
____________________________

SELECT t1.nameTeam AS LocalTeam, t2.nameTeam AS VisitingTeam, m.localTeamGoals, m.visitingTeamGoals
FROM Matches m
JOIN Teams t1 ON m.idLocalTeam = t1.idTeam
JOIN Teams t2 ON m.idVisitingTeam = t2.idTeam
WHERE m.idPrincipalReferee = 1;
_________________________________

SELECT t1.nameTeam AS LocalTeam, t2.nameTeam AS VisitingTeam, m.localTeamGoals, m.visitingTeamGoals
FROM Matches m
JOIN Teams t1 ON m.idLocalTeam = t1.idTeam
JOIN Teams t2 ON m.idVisitingTeam = t2.idTeam
WHERE m.phase = 'Cuartos';
_______________________________________

SELECT nameComplete
FROM Referees
WHERE category = 'Principal' AND experienceYears > 5;
_____________________________________________________

SELECT p.nameComplete, t.nameTeam
FROM Players p
JOIN Teams t ON p.idTeam = t.idTeam
WHERE p.position = 'Goalkeeper';
____________________________________________________

SELECT t1.nameTeam AS LocalTeam, t2.nameTeam AS VisitingTeam, m.localTeamGoals, m.visitingTeamGoals
FROM Matches m
JOIN Teams t1 ON m.idLocalTeam = t1.idTeam
JOIN Teams t2 ON m.idVisitingTeam = t2.idTeam
WHERE m.localTeamGoals > m.visitingTeamGoals;
_________________________________________________

SELECT DISTINCT CASE 
                   WHEN m.localTeamGoals > m.visitingTeamGoals THEN t1.nameTeam
                   WHEN m.visitingTeamGoals > m.localTeamGoals THEN t2.nameTeam
                   ELSE 'Empate' 
                 END AS TeamThatAdvances
FROM Matches m
JOIN Teams t1 ON m.idLocalTeam = t1.idTeam
JOIN Teams t2 ON m.idVisitingTeam = t2.idTeam
WHERE m.phase = 'Cuartos' AND (
    m.localTeamGoals > m.visitingTeamGoals OR 
    m.visitingTeamGoals > m.localTeamGoals);

