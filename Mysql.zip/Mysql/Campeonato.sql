CREATE DATABASE IF NOT EXISTS Campeonato 
DEFAULT CHARACTER SET utf8mb4 
DEFAULT COLLATE utf8mb4_unicode_ci;

USE Campeonato;

CREATE table if not exists Teams (
    idTeam INTEGER PRIMARY KEY AUTO_INCREMENT,
    nameTeam VARCHAR(50) NOT NULL,
    cityOrigin VARCHAR(50) NOT NULL,
    foundationYear INTEGER NOT NULL
);

CREATE table if not exists  Referees (
    idReferee INTEGER PRIMARY KEY AUTO_INCREMENT,
    nameComplete VARCHAR(50) NOT NULL,
    experienceYears INTEGER NOT NULL,
    category ENUM('Principal', 'Assistant') NOT NULL
);

CREATE TABLE Matches (
    idMatch INTEGER PRIMARY KEY AUTO_INCREMENT,
    idLocalTeam INTEGER NOT NULL,
    idVisitingTeam INTEGER NOT NULL,
    matchDay DATE NOT NULL,
    idPrincipalReferee INTEGER NOT NULL,
    localTeamGoals INTEGER NOT NULL,
    visitingTeamGoals INTEGER NOT NULL,
    phase ENUM('Cuartos', 'Semifinales', 'Final') NOT NULL,
    FOREIGN KEY (idLocalTeam) REFERENCES Teams(idTeam) ON DELETE CASCADE,
    FOREIGN KEY (idVisitingTeam) REFERENCES Teams(idTeam) ON DELETE CASCADE,
    FOREIGN KEY (idPrincipalReferee) REFERENCES Referees(idReferee) ON DELETE CASCADE
);

CREATE table if not exists  Players (
    idPlayers INTEGER PRIMARY KEY AUTO_INCREMENT,
    nameComplete VARCHAR(50) NOT NULL,
    numberTShirt INTEGER CHECK (numberTShirt > 0 AND numberTShirt < 100),
    position ENUM('Goalkeeper', 'Defense', 'Midfielder', 'Forward') NOT NULL,
    idTeam INTEGER,
    FOREIGN KEY (idTeam) REFERENCES Teams(idTeam) ON DELETE CASCADE
);

CREATE TABLE Match_Referees (
    idMatch INTEGER,
    idReferee INTEGER,
    category ENUM('Principal', 'Assistant') NOT NULL, -- Se mantiene aquí si cambia por partido
    PRIMARY KEY (idMatch, idReferee),
    FOREIGN KEY (idMatch) REFERENCES Matches(idMatch) ON DELETE CASCADE,
    FOREIGN KEY (idReferee) REFERENCES Referees(idReferee) ON DELETE CASCADE
);

drop database 